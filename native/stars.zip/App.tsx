import { Provider } from 'react-redux';
import { store } from './src/app/store';
import { DrawerNavigation } from './src/components/Drawer/Drawer';
import { NavigationContainer } from '@react-navigation/native';

export default function App() {
  return (
    <Provider store={store}>
        <NavigationContainer>
          <DrawerNavigation />
        </NavigationContainer>
    </Provider>
  );
}
