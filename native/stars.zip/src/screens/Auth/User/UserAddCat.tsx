import React, { useState } from 'react'
import { Alert, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import RNPickerSelect from 'react-native-picker-select';
import { IAddCat } from '../../../types/types';
import { useAppDispatch, useAppSelector } from '../../../app/hooks';
import { addCat } from '../../../features/cats/catsAPI';

const options = [
  { value: "1", label: 'Astronomy' },
  { value: "2", label: 'Astrophysics' },
  { value: "3", label: 'Cosmology' },
]

const UserAddCat = () => {
  const [catValue, setCatValue] = useState<string>('')
  const { user } = useAppSelector(state => state.signinStore)
  const dispatch = useAppDispatch()

  const handleSubmit = () => {
    if (catValue !== '') {
      const obj: IAddCat = {
        uid: user?.id!,
        cat: +catValue
      }
      dispatch(addCat(JSON.stringify(obj)))
      setCatValue('')
      Alert.alert('Added')
    }
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar
        animated={true}
        backgroundColor="#2b2572"
      />
      <ScrollView style={{ padding: 15 }}>
        <Text style={styles.title}>Add category</Text>
        <View style={styles.content}>
          <RNPickerSelect
            onValueChange={(value) => setCatValue(value)}
            items={options}
            style={pickerSelectStyles}
            placeholder={{ label: "Choose category", value: '' }}
            value={catValue}
          />
          <TouchableOpacity
            style={styles.btn}
            onPress={() => handleSubmit()}
            accessibilityLabel="Press Me Btn"
          >
            <Text style={[styles.btnText]}>Add</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  title: {
    fontSize: 22,
    lineHeight: 28,
    color: '#8a6b15'
  },
  content: {
    marginTop: 10,
    marginBottom: 40
  },
  btn: {
    backgroundColor: '#2b2572',
    height: 50,
    borderRadius: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15
  },
  btnText: {
    color: 'white',
    lineHeight: 28,
    fontSize: 20
  },
})

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    fontSize: 18,
    lineHeight: 28
  },
  inputAndroid: {
    fontSize: 18,
    lineHeight: 28,
  }
})

export default UserAddCat
