import React from 'react'
import { SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { useAppSelector } from '../../../app/hooks'

const UserChars = ({ navigation }: any) => {
  const { user } = useAppSelector(state => state.signinStore)

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar
        animated={true}
        backgroundColor="#2b2572"
      />
      <ScrollView style={{ padding: 15 }}>
        <View>
          <TouchableOpacity
            onPress={() => navigation.navigate('UserAddCat')}
            style={styles.touch}
          >
            <Text style={styles.text}>Add category</Text>
          </TouchableOpacity>
        </View>
        <View>
          <TouchableOpacity
            onPress={() => navigation.navigate('UserViewCat', { uid: user?.id })}
            style={styles.touch}
          >
            <Text style={styles.text}>View category</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  touch: {
    marginVertical: 10,
    borderWidth: 2,
    borderColor: '#2b2572',
    borderRadius: 3,
    minHeight: 60,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    lineHeight: 28,
    fontSize: 20,
    fontWeight: 'bold'
  },
})

export default UserChars
