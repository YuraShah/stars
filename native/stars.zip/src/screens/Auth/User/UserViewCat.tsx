import React, { useEffect } from 'react'
import { ActivityIndicator, FlatList, RefreshControl, SafeAreaView, StatusBar, StyleSheet, Text, View } from 'react-native'
import { useAppDispatch, useAppSelector } from '../../../app/hooks'
import { getViewCats } from '../../../features/cats/catsAPI'

const UserViewCat = ({ route }: any) => {
  const { uid } = route.params
  const dispatch = useAppDispatch()
  const { catData, catPending, catRej, catResp } = useAppSelector(state => state.catsStore)

  useEffect(() => {
    if (!uid) return
    dispatch(getViewCats(JSON.stringify(uid)))
  }, [uid])

  const onRefresh = React.useCallback(() => {
    dispatch(getViewCats(JSON.stringify(uid)))
  }, [])

  if (catPending) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color='#0492c2' />
      </View>
    )
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar
        animated={true}
        backgroundColor="#2b2572"
      />
      <FlatList
        data={[]}
        renderItem={() => <></>}
        style={styles.container}
        refreshControl={<RefreshControl refreshing={catPending} onRefresh={onRefresh} colors={['#2b2572']} progressBackgroundColor='white' />}
        ListHeaderComponent={
          <>
            <Text style={styles.title}>View Category</Text>
            <View style={{marginTop: 20, marginBottom: 40}}>
              {catRej ? <Text style={styles.textErr}>Connection problem. Try refreshing the page</Text>
                :
                catResp && catData.length === 0 ? <Text style={styles.textErr}>No categories added</Text>
                  :
                  catResp && catData.length > 0 &&
                  <FlatList
                    data={catData}
                    renderItem={({ item: data }) =>
                      <View style={styles.dataContainer}>
                        <Text style={styles.dataText}>● {data.cat === 1 ? 'Astronomy' : data.cat === 2 ? 'Astrophysics' : 'Cosmology'}</Text>
                      </View>
                    }
                  />
              }
            </View>
          </>
        }
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
  container: {
    padding: 15
  },
  title: {
    fontSize: 22,
    lineHeight: 28,
    color: '#8a6b15'
  },
  textErr: {
    fontSize: 20,
    lineHeight: 28,
  },
  dataContainer: {
    marginBottom: 20
  },
  dataText: {
    fontSize: 20,
    lineHeight: 28,
  },
})

export default UserViewCat
