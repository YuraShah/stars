import React, { useState } from 'react'
import { RefreshControl, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, useWindowDimensions } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { SigninForm } from '../../types/types'
import { Controller, useForm } from 'react-hook-form'
import { signIn } from '../../features/signin/signinAPI'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons'
import { TextInput } from 'react-native-gesture-handler'

const Signin = () => {
  const { control, handleSubmit, formState: { errors }, reset } = useForm<SigninForm>()
  const { signinPend, signinRej, signinErr } = useAppSelector((state) => state.signinStore)
  const dispatch = useAppDispatch();
  const [isShowPass, setIsShowPass] = useState<boolean>(false);
  const windowWidth = useWindowDimensions().width;
  const [refreshing, setRefreshing] = React.useState(false);

  const save = async (data: SigninForm) => {
    await dispatch(signIn(JSON.stringify({ email: data.email, password: data.password })))
  }

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    reset()
    setIsShowPass(false)
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar
        animated={true}
        backgroundColor="#2b2572"
      />
      <ScrollView
        style={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2b2572']} progressBackgroundColor='white' />}
      >
        <Text style={[styles.title]}>Sign In</Text>
        {signinRej ? <Text style={[styles.attentionText]}>Connection problem. Try refreshing the page</Text> :
          <View>
            {signinErr !== '' && <Text style={styles.attentionText}>{signinErr}</Text>}
            <View
              style={[styles.form, windowWidth >= 780 && { width: '70%' }]}
            >
              <View style={styles.formRow}>
                <Text style={[styles.formRowText]}>E-mail</Text>
                {errors.email && <Text style={[styles.errorText]}>Invalid email address</Text>}
                <Controller
                  control={control}
                  rules={{
                    required: true, pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i
                  }}
                  render={({ field: { onChange, onBlur, value } }) => (
                    <TextInput
                      onBlur={onBlur}
                      onChangeText={onChange}
                      value={value}
                      style={[styles.input]}
                      accessibilityLabel='My Input Mail'
                      autoCapitalize="none"
                    />
                  )}
                  name="email"
                />
              </View>
              <View style={styles.formRow}>
                <Text style={[styles.formRowText]}>Password</Text>
                {errors.password && <Text style={[styles.errorText]}>Invalid password</Text>}
                <View style={styles.passInputContainer}>
                  <Controller
                    control={control}
                    rules={{
                      required: true, pattern: /^(?=.*[0-9])(?=.*[a-zա-ֆ])(?=.*[A-ZԱ-Ֆ]).{8,32}$/
                    }}
                    render={({ field: { onChange, onBlur, value } }) => (
                      <TextInput
                        onBlur={onBlur}
                        onChangeText={onChange}
                        value={value}
                        style={[styles.inputPass]}
                        secureTextEntry={!isShowPass ? true : false}
                        accessibilityLabel='My Input Pass'
                        autoCapitalize="none"
                      />
                    )}
                    name="password"
                  />
                  {!isShowPass ?
                    <TouchableOpacity
                      onPress={() => setIsShowPass(true)}
                      style={styles.passInputTouch}
                      accessibilityLabel='My Button Not Show'
                    >
                      <FontAwesomeIcon icon={faEye} />
                    </TouchableOpacity>
                    : <TouchableOpacity
                      onPress={() => setIsShowPass(false)}
                      style={styles.passInputTouch}
                      accessibilityLabel='My Button Show'
                    >
                      <FontAwesomeIcon icon={faEyeSlash} />
                    </TouchableOpacity>}
                </View>
              </View>
              <TouchableOpacity
                style={styles.btn}
                onPress={handleSubmit(save)}
                accessibilityLabel="Press Me Btn"
              >
                <Text style={[styles.btnText]}>{signinPend ? 'Sign In...' : 'Sign In'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        }
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 15,
  },
  title: {
    fontSize: 20,
    color: '#2b2572',
    fontWeight: 'bold',
    lineHeight: 28
  },
  attentionText: {
    lineHeight: 28,
    color: '#2b2572',
    marginTop: 20,
    fontSize: 20,
  },
  form: {
    marginTop: 10,
    marginBottom: 20,
    padding: 5
  },
  formRow: {
    marginVertical: 10
  },
  formRowText: {
    fontSize: 18,
    marginBottom: 7,
    lineHeight: 28,
    fontWeight: 'bold',
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    marginBottom: 7,
    lineHeight: 28
  },
  input: {
    paddingHorizontal: 20,
    fontSize: 18,
    backgroundColor: 'white',
    borderRadius: 4,
    flex: 1,
    height: 48
  },
  btn: {
    backgroundColor: '#2b2572',
    height: 50,
    borderRadius: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15
  },
  btnText: {
    color: 'white',
    lineHeight: 28,
    fontSize: 20
  },
  link: {
    color: '#246782',
    textDecorationLine: 'underline'
  },
  passInputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  passInputTouch: {
    backgroundColor: 'white',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    width: 48,
    paddingLeft: 5,
    paddingRight: 7,
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
  },
  inputPass: {
    paddingHorizontal: 20,
    fontSize: 18,
    backgroundColor: 'white',
    borderTopLeftRadius: 4,
    borderBottomLeftRadius: 4,
    flex: 1,
    height: 48
  }
})

export default Signin
