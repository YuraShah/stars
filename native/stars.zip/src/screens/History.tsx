import React from 'react'
import { SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, View } from 'react-native'

const History = () => {
   return (
      <SafeAreaView style={{ flex: 1 }}>
         <StatusBar
            animated={true}
            backgroundColor="#2b2572"
         />
         <ScrollView style={{ padding: 15 }}>
            <Text style={styles.title}>History</Text>
            <View style={styles.article}>
               <Text style={styles.text}>Stars was founded in 2024 by a group of friends who were captivated by the night sky. What started as a small blog quickly grew into a comprehensive resource for space enthusiasts around the world. Our love for space drove us to create a platform where people could learn about and discuss the wonders of the universe.</Text>
               <Text style={styles.text}>From the very beginning, our vision was clear: to create a space where knowledge and passion for the cosmos could be shared freely. We began by writing about the basics of astronomy, sharing beautiful images of celestial events, and covering the latest news in space exploration. As our audience grew, so did our ambition.</Text>
               <Text style={styles.text}>Over the years, Stars has evolved, but our core mission remains the same: to inspire and educate. We have expanded our content to include a variety of media, from detailed articles and stunning images to interactive tools and engaging videos. Our interactive star maps and virtual telescopes allow users to explore the night sky from the comfort of their own homes. We've also hosted webinars and live Q&A sessions with leading astronomers and scientists, providing direct access to experts in the field.</Text>
               <Text style={styles.text}>We are proud to have built a community of curious minds and space lovers. Our forums and social media channels are buzzing with discussions, questions, and shared discoveries. Members of our community have contributed their own observations and insights, enriching the collective knowledge of our site.</Text>
               <Text style={styles.text}>As we continue to grow, we remain committed to exploring the cosmos and sharing our discoveries with you. We are constantly working on new features and content to keep our audience engaged and informed. Our upcoming projects include a podcast series, more interactive educational tools, and collaborative projects with other space organizations.</Text>
               <Text style={styles.text}>Thank you for being a part of our journey. Together, we reach for the stars.</Text>
            </View>
         </ScrollView>
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   title: {
      fontSize: 22,
      lineHeight: 28,
      color: '#8a6b15'
   },
   article: {
      marginTop: 5,
      marginBottom: 50
   },
   text: {
      lineHeight: 28,
      fontSize: 18,
      marginVertical: 5
   }
})

export default History
