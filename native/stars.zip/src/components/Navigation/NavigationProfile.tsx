import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { TouchableOpacity } from "react-native";
import { DrawerActions } from '@react-navigation/native';
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { useAppSelector } from "../../app/hooks";
import UserChars from "../../screens/Auth/User/UserChars";
import UserAddCat from "../../screens/Auth/User/UserAddCat";
import UserViewCat from "../../screens/Auth/User/UserViewCat";



const Stack = createNativeStackNavigator();

export const NavigationProfile = () => {
   const { user } = useAppSelector(state => state.signinStore)
   const stackUserTitle = user ? `User (${user.username})` : "User"

   return (
      <Stack.Navigator>
         <Stack.Screen
            name="UserChars"
            component={UserChars}
            options={({ navigation }) => ({
               title: stackUserTitle,
               headerStyle: { backgroundColor: '#2b2572' },
               headerTintColor: 'white',
               headerTitleStyle: { fontWeight: 'bold', fontSize: 19 },
               headerRight: () => (
                  <TouchableOpacity
                     onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())}
                     accessibilityLabel='Press Char'
                     style={{ width: 48, height: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' }}
                  >
                     <FontAwesomeIcon
                        icon={faBars}
                        size={18}
                        style={{ color: "white", marginTop: 4 }}
                     />
                  </TouchableOpacity>
               )
            })}
         />
         <Stack.Screen
            name="UserAddCat"
            component={UserAddCat}
            options={{
               title: "Add category",
               headerStyle: { backgroundColor: '#2b2572' },
               headerTintColor: 'white',
               headerTitleStyle: { fontWeight: 'bold', fontSize: 19 }
            }} />
         <Stack.Screen
            name="UserViewCat"
            component={UserViewCat}
            options={{
               title: "View Category",
               headerStyle: { backgroundColor: '#2b2572' },
               headerTintColor: 'white',
               headerTitleStyle: { fontWeight: 'bold', fontSize: 19 }
            }} />
      </Stack.Navigator>
   )
}