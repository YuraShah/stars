import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Image, Text, TouchableOpacity, View } from "react-native";
import { DrawerActions } from '@react-navigation/native';
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { useAppDispatch, useAppSelector } from "../../app/hooks";
import Home from "../../screens/Home";
import History from "../../screens/History";
import About from "../../screens/About";


const Stack = createNativeStackNavigator();

export const Navigation = () => {
   const dispatch = useAppDispatch();

   return (
      <Stack.Navigator initialRouteName="Home">
         <Stack.Screen name="Home"
            component={Home}
            options={({ navigation }: any) => ({
               headerTitle: () =>
                  <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 7 }}>
                     <Image
                        style={{ width: 50, height: 50, resizeMode: 'contain' }}
                        source={require('../../../assets/logo.png')}
                     />
                     <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 18 }}>Stars</Text>
                  </View>,
               headerStyle: { backgroundColor: '#2b2572' },
               headerTintColor: 'white',
               headerTitleStyle: { fontWeight: 'bold', fontSize: 19 },
               headerTitleAlign: 'center',
               headerLeft: () => (
                  <TouchableOpacity
                     onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
                     accessibilityLabel="Press Me Open Drawer"
                     style={{ width: 48, height: 48, alignItems: 'center', flexDirection: 'row' }}
                  >
                     <FontAwesomeIcon
                        icon={faBars}
                        size={23}
                        style={{ color: "white", marginTop: 3, marginRight: 20 }}
                     />
                  </TouchableOpacity>
               ),
            })}
         />
         <Stack.Screen
            name="History"
            component={History}
            options={({ navigation }) => ({
               title: "History",
               headerStyle: { backgroundColor: '#2b2572' },
               headerTintColor: 'white',
               headerTitleStyle: { fontWeight: 'bold', fontSize: 19 },
               headerRight: () => (
                  <TouchableOpacity
                     onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())}
                     accessibilityLabel="Press Me 1"
                     style={{ width: 48, height: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' }}
                  >
                     <FontAwesomeIcon
                        icon={faBars}
                        size={20}
                        style={{ color: "white", marginTop: 4 }}
                     />
                  </TouchableOpacity>
               )
            })}
         />
         <Stack.Screen
            name="About"
            component={About}
            options={({ navigation }) => ({
               title: "About",
               headerStyle: { backgroundColor: '#2b2572' },
               headerTintColor: 'white',
               headerTitleStyle: { fontWeight: 'bold', fontSize: 19 },
               headerRight: () => (
                  <TouchableOpacity
                     onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())}
                     accessibilityLabel="Press Me 2"
                     style={{ width: 48, height: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' }}
                  >
                     <FontAwesomeIcon
                        icon={faBars}
                        size={20}
                        style={{ color: "white", marginTop: 4 }}
                     />
                  </TouchableOpacity>
               )
            })}
         />
      </Stack.Navigator>
   )
}