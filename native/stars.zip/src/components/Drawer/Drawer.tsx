import 'react-native-gesture-handler';
import { DrawerContentScrollView, DrawerItem, DrawerItemList, createDrawerNavigator } from '@react-navigation/drawer';
import { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import * as ScreenOrientation from 'expo-screen-orientation';
import { Alert, Image, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import About from '../../screens/About';
import { DrawerActions } from '@react-navigation/native';
import History from '../../screens/History';
import { getUser, logout } from '../../features/signin/signinSlice';
import Signin from '../../screens/Auth/Signin';
import { Navigation } from '../Navigation/Navigation';
import { NavigationProfile } from '../Navigation/NavigationProfile';
import { addToken } from '../../features/signin/signinAPI';


const Drawer = createDrawerNavigator();

export const DrawerNavigation = () => {
  const dispatch = useAppDispatch();
  const { token, user } = useAppSelector(state => state.signinStore)
  const windowWidth = useWindowDimensions().width;

  useEffect(() => {
    dispatch(getUser());
  }, [dispatch, token]);

  useEffect(() => {
    dispatch(addToken())
  }, [token])

  useEffect(() => {
    ScreenOrientation.unlockAsync();
  }, []);

  function CustomDrawerContent(props: any) {
    const { navigation, state } = props;

    const getActiveRouteState = (state: any): any => {
      if (!state || !state.routes || state.routes.length === 0) {
        return null;
      }
      const route = state.routes[state.index];
      if (route.state) {
        return getActiveRouteState(route.state);
      }

      return route;
    };
    const currentRoute = getActiveRouteState(state);
    const currentRouteName = currentRoute ? currentRoute.name : 'Unknown';

    const logoutFunc = () => {
      dispatch(logout())
      Alert.alert('', 'You have logged out of account', [
        { text: 'Okey', style: 'default', },
      ]);
      navigation.dispatch(DrawerActions.closeDrawer())
    }

    return (
      <ScrollView contentContainerStyle={{ flex: 1 }}>
        <DrawerContentScrollView
          contentContainerStyle={{
            paddingTop: 0,
            flexGrow: 1,
          }}
          {...props}
        >
          <View
            style={{
              backgroundColor: "#2b2572",
              flexDirection: 'row',
              alignItems: 'center',
              gap: 10,
              paddingVertical: 7,
              paddingStart: 15,
              marginBottom: 10
            }}>
            <Image
              style={{ width: 50, height: 50, resizeMode: 'contain' }}
              source={require('../../../assets/logo.png')}
            />
            <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 18 }}>Stars</Text>
          </View>
          <DrawerItem
            label="Home"
            onPress={() => navigation.navigate('Home')}
            labelStyle={{
              color: (currentRouteName === 'Home' || currentRouteName === 'All') ? 'white' : 'black',
              lineHeight: 28
            }}
            style={[(currentRouteName === 'Home' || currentRouteName === 'All') && { backgroundColor: '#2b2572' }]}
          />
          {user ?
            <DrawerItem
              label="Profile"
              onPress={() => navigation.navigate('ProfileDetails', { screen: 'UserChars' })}
              labelStyle={{
                color: currentRouteName !== 'UserChars' ? 'black' : 'white',
                lineHeight: 28
              }}

              style={[currentRouteName === 'UserChars' && { backgroundColor: '#2b2572' }]}
            /> :
            <DrawerItem
              label="Register"
              onPress={() => navigation.navigate('WebView', { url: 'https://' })}
              labelStyle={{
                color: 'black',
                lineHeight: 28
              }}
            />
          }
          <DrawerItemList {...props} />
        </DrawerContentScrollView>
        <View>
          {user &&
            <DrawerItem
              label="Sign Out"
              onPress={() => logoutFunc()}
              labelStyle={{
                color: 'black',
                lineHeight: 28,
                marginBottom: 10
              }}
            />
          }
        </View>
      </ScrollView>
    );
  }


  return (
    <Drawer.Navigator
      drawerContent={props => <CustomDrawerContent {...props} />}
      screenOptions={{
        drawerStyle: windowWidth >= 780 ? { width: '45%' } : null,
        drawerActiveBackgroundColor: '#2b2572',
        drawerActiveTintColor: 'white',
        drawerInactiveTintColor: 'black'
      }}
    >
      <Drawer.Screen
        name='All'
        component={Navigation}
        options={{ headerShown: false, drawerItemStyle: { display: 'none' } }}
      />
      {!user ? (
        <>
          <Drawer.Screen
            name='SignIn'
            component={Signin}
            options={{
              title: 'Sign In',
              headerStyle: { backgroundColor: '#2b2572' },
              headerTintColor: 'white',
              headerTitleStyle: { fontWeight: 'bold', marginTop: -3 },
            }}
          />
        </>
      )
        : (
          <>
            <Drawer.Screen
              name='ProfileDetails'
              component={NavigationProfile}
              options={{ headerShown: false, drawerItemStyle: { display: 'none' } }}
            />
          </>)}
      <Drawer.Screen
        name='History'
        component={History}
        options={{
          title: 'History',
          headerStyle: { backgroundColor: '#2b2572' },
          headerTintColor: 'white',
          headerTitleStyle: { fontWeight: 'bold', fontSize: 16, marginTop: -3 },
          headerLeftContainerStyle: { width: 48, flexDirection: 'row', alignItems: 'center' },
          drawerLabelStyle: { lineHeight: 28 },
        }}
      />
      <Drawer.Screen
        name='About'
        component={About}
        options={{
          title: 'About',
          headerStyle: { backgroundColor: '#2b2572' },
          headerTintColor: 'white',
          headerTitleStyle: { fontWeight: 'bold', fontSize: 18, marginTop: -3 },
          headerLeftContainerStyle: { width: 48, flexDirection: 'row', alignItems: 'center' },
          drawerLabelStyle: { lineHeight: 28 },
        }}
      />
    </Drawer.Navigator>
  )
}