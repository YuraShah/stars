import { faArrowRotateRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, StatusBar, ScrollView, View, SafeAreaView, TouchableOpacity, BackHandler } from 'react-native';
import { WebView } from 'react-native-webview';

const WebViewScreen = ({ route }: any) => {
   const { url } = route.params;
   const [isVisible, setIsVisible] = useState(true)
   const [scrolledToTop, setScrolledToTop] = React.useState(0)
   const webViewRef = useRef<WebView | null>(null);
   const [canGoBack, setCanGoBack] = useState(false);
   const navigation = useNavigation();

   const hideSpinner = () => {
      setIsVisible(false)
   }

   const onRefresh = React.useCallback(() => {
      if (webViewRef.current) {
         setIsVisible(true)
         webViewRef?.current?.reload();
      }
   }, []);

   const handleBackPress = () => {
      if (canGoBack) {
         webViewRef.current?.goBack();
         return true;
      } else {
         navigation.goBack();
         return true;
      }
   };

   useEffect(() => {
      BackHandler.addEventListener("hardwareBackPress", handleBackPress);

      return () => {
         BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
      };
   }, [canGoBack]);

   const spinner = () => {
      return (
         <ActivityIndicator
            size="large"
            color='#2b2572'
            style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }}
         />
      )
   }

   return (
      <SafeAreaView style={{ flex: 1 }}>
         <StatusBar
            animated={true}
            backgroundColor="#2b2572"
         />
         <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
            <View
               style={{
                  position: 'absolute',
                  zIndex: 1,
                  backgroundColor: '#2b2572',
                  opacity: scrolledToTop <= 65 ? 1 : 0,
                  top: 0,
                  left: '50%',
                  width: 40,
                  marginLeft: -20,
               }}
            >
               <TouchableOpacity
                  onPress={() => onRefresh()}
                  style={{ alignItems: 'center', paddingVertical: 5 }}
                  disabled={scrolledToTop <= 65 ? false : true}
               >
                  <FontAwesomeIcon icon={faArrowRotateRight} size={20} color='white' />
               </TouchableOpacity>
            </View>
            <WebView
               source={{ uri: url }}
               style={{ flex: 1 }}
               onLoad={() => hideSpinner()}
               ref={webViewRef}
               onScroll={(event) => {
                  const { contentOffset: { y } } = event.nativeEvent;
                  setScrolledToTop(y)
               }}
               onNavigationStateChange={(navState) => setCanGoBack(navState.canGoBack)}
               renderLoading={spinner}
            />
            {isVisible && (
               <ActivityIndicator
                  size="large"
                  color='#2b2572'
                  style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }}
               />
            )}
         </ScrollView>
      </SafeAreaView>
   );
}

export default WebViewScreen;