import { createSlice } from '@reduxjs/toolkit';
import { addToken, signIn } from './signinAPI';
import "core-js/stable/atob";
import { IUser } from '../../types/types';
import { jwtDecode } from 'jwt-decode';
import "core-js/stable/atob";
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ISigninSlice {
   signinPend: boolean,
   signinRej: boolean,
   signinErr: string,
   user: IUser | null;
   uId: [] | number[],
   token: any,
}

const initialState: ISigninSlice = {
   signinPend: false,
   signinRej: false,
   signinErr: '',
   user: null,
   token: null,
   uId: []
}


const signinSlice = createSlice({
   name: 'signin',
   initialState,
   reducers: {
      logout: (state) => {
         state.token = null
         AsyncStorage.removeItem('token')
         state.user = null
      },
      getUser: (state) => {
         const token = state.token
         if (token) {
            try {
               let userDec: any = jwtDecode(token);
               return {
                  ...state,
                  user: userDec.data,
                  token,
               }
            } catch (err: any) {
               console.log(err.message)
            }
         }
      },
   },
   extraReducers: (builder) => {
      builder
         .addCase(addToken.fulfilled, (state, action) => {
            state.token = action.payload
         })

         .addCase(signIn.pending, (state: ISigninSlice, action) => {
            state.signinPend = true
            state.signinRej = false
            state.signinErr = ''
         })
         .addCase(signIn.fulfilled, (state: ISigninSlice, action) => {
            if (action.payload && (action.payload[0] !== 'User is not found')) {
               state.token = action.payload[0]?.token
               const userL: any = jwtDecode(action.payload[0]?.token);
               state.user = userL.data
               AsyncStorage.setItem('token', action.payload[0]?.token)
            } else {
               state.signinErr = 'User is not found'
            }
            state.signinPend = false
            state.signinRej = false
         })
         .addCase(signIn.rejected, (state: ISigninSlice, action) => {
            state.signinPend = false
            state.signinRej = true
            state.signinErr = ''
         })
   }
})

export default signinSlice.reducer
export const { getUser, logout } = signinSlice.actions