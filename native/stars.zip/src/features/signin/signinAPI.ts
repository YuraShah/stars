import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { LINKS } from '../../types/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import "core-js/stable/atob";

export const signIn = createAsyncThunk(
   'sign/in',
   async (obj: string, thunkAPI) => {
      const response = await axios.post(LINKS.SIGNIN, obj, { 
         headers: {
            "Content-Type": "application/json",
            // "Authorization": await AsyncStorage.getItem('token')
         }
      })
         .then((r) => {
            return r.data
         })
         .catch((err) => {
            console.log(err)
            return thunkAPI.rejectWithValue(err)
         })
      return response
   }
)

export const addToken = createAsyncThunk(
   'addtoken',
   async () => {
      const result = await AsyncStorage.getItem('token')
      return result
   }
)